import RecordingDetailsPage from "@/components/RecordingDetailsPage";

export default function RecordingPage() {
  return <RecordingDetailsPage />;
}
