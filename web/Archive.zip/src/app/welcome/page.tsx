"use client";

import WelcomePage from "@/components/WelcomePage";

export default function Welcome() {
  return <WelcomePage />;
}
