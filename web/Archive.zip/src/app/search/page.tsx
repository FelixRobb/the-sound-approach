import SearchPage from "@/components/SearchPage";

export default function Search() {
  return <SearchPage />;
}
