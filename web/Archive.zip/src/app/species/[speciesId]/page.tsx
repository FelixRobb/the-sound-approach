import SpeciesDetailsPage from "@/components/SpeciesDetailsPage";

export default function SpeciesPage() {
  return <SpeciesDetailsPage />;
}
